#include <stdio.h>
#include <limits.h>
#define SLAB1 100
#define SLAB2 200
#define RATE2 225L
#define RATE3 450L
#define FIXED 5000L
static unsigned int units_used(unsigned short prev,unsigned short curr) { return (unsigned int)(unsigned short)(curr-prev); }
static long bill(int units) {
    if(units<0) return -1;
    long p=FIXED;
    if(units>SLAB1) { int n=units<SLAB2?units-SLAB1:SLAB2-SLAB1; p+=(long)n*RATE2; }
    if(units>SLAB2) p+=(long)(units-SLAB2)*RATE3;
    return p;
}
int main(void) {
    int tests[]={0,100,150,200,350};
    for(size_t i=0;i<sizeof tests/sizeof tests[0];i++){long p=bill(tests[i]);printf("%3d units -> Rs %ld.%02ld\n",tests[i],p/100,p%100);}
    printf("Rollover 65400 -> 120: %u units\n",units_used(65400,120));
    return 0;
}
