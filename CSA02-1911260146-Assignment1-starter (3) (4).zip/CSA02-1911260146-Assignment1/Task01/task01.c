/* Task 1: Basic billing data model demonstrator */
#include <stdio.h>
int main(void) {
    unsigned int previous = 1200, current = 1530;
    unsigned int units = current - previous;
    long fixed_charge_paise = 5000L;
    long energy_charge_paise = 0L; /* first 100 units are free in this example */
    long total_paise = fixed_charge_paise + energy_charge_paise;
    printf("Previous reading: %u\nCurrent reading: %u\nUnits: %u\n", previous, current, units);
    printf("Total: Rs %ld.%02ld\n", total_paise / 100, total_paise % 100);
    return 0;
}
