# C Programming Assignment 1 — Report Draft

**Student:** R. Vishwa  
**Register Number:** 1911260146  
**Title:** Design, Implement and Validate a Reliable Billing Program for a Rural Electricity Co-operative  
**GitHub repository:** [Paste the working repository URL here]  
**Compiler:** GCC 14.2.0 (Linux environment used for starter validation)

> This is a report draft. Add your own actual run screenshots and measured values before submission.

## Task 1 — Problem analysis and data
Inputs: household ID/category, previous and current meter readings. Outputs: consumption, energy charge, fixed charge and total bill. Tariff rates and slab boundaries are configuration constants in the original design. Use unsigned meter values for the 16-bit register and integer paise for money. Assumptions: register capacity is 65536 states; a lower current reading indicates one rollover only when rollover is valid for the meter-reading interval; invalid/unexplained decreases should be flagged in a production system. In the text representation, converting d digits and comparing numeric values takes O(d) time; storing the string requires O(d) characters, while a fixed-width integer uses O(1) space.

## Task 2 — Data types
Use `unsigned short` only where the platform confirms 16-bit range, `unsigned int`/`uint32_t` for bounded units, `long long` or `uint64_t` for large totals, and integer paise for money. Check `sizeof`, `limits.h`, and `float.h` on the target compiler; sizes are platform-dependent. A 16-bit unsigned meter register wraps modulo 65536. For the provided readings, `(unsigned short)(120-65400)` gives 256. Addition time is O(1) for integer or double; integer paise avoids binary floating-point rounding accumulation.

## Task 3 — Constants and billing formula
Use named macros for compile-time slab limits/rates in the original task. The bill is fixed charge plus each slab's units multiplied by that slab's paise rate. Changing `RATE2_PAISE` in one place ensures consistency. `const` objects have a type and debugger visibility; macros are textual substitutions. Runtime configuration is preferable for frequently revised tariffs.

## Task 4 — Macros
Fully parenthesise macro parameters and the complete expression. `SQUARE(x)` must be `((x)*(x))`; `x*x` can mis-evaluate `SQUARE(a+1)`. A macro like `MAX(i++, j)` may evaluate an argument more than once. Static inline functions provide type checking and evaluate arguments once; macro expansion may increase code size with repeated use.

## Task 5 — Headers and conditional compilation
`billing.h` uses an include guard. Quoted includes search the local project first; angle brackets are normally used for system headers. `-DDEBUG` enables compile-time diagnostic output using `#ifdef DEBUG`. A runtime flag adds a conditional check to each relevant call but allows changing debug mode without recompiling.

## Task 6 — Input/output
Check `scanf`'s return count before using values. Use matching format specifiers: `%d` for `int`, `%u` for `unsigned`, `%ld` for `long`, `%lld` for `long long`, `%f` for `float` output, `%lf` for `double` input to `scanf`, `%c` for character, and `%s` for a bounded string. `fgets` plus `strtol` can provide stronger line-level validation and recovery; processing a line of length L takes O(L) time and O(L) buffer space.

## Task 7 — Type conversion and precision
Demonstrations include `7/2` yielding 3, `(double)7/2` yielding 3.50, `0.1+0.2` not being exactly 0.3 in binary floating point, and `(int)3.99` yielding 3. Integer paise provides exact addition for currency; define a documented rounding rule whenever fractional paise arises.

## Task 8 — Compilation process
Use `gcc -E` for preprocessed source, `gcc -S` for assembly, `gcc -c` for an object file, and a final GCC link command for the executable. Preprocessor errors are distinct from compile errors, link errors (for example, missing function definition), and runtime errors. Compile with `-Wall -Wextra -Wpedantic`; include actual command output/screenshots in the final report. With multiple `.c` files, only changed translation units need recompilation before relinking, while object files occupy additional disk space.

## Task 9 — Implementation and testing
The source demonstrates slab billing and meter rollover. Complete a test table on your machine for zero, 100, 150, 200, 350 units, rollover 65400 to 120, invalid letters, negative readings and inconsistent decreases. The expected bills under the supplied tariff are Rs 50.00, Rs 50.00, Rs 162.50, Rs 275.00 and Rs 950.00 respectively. Note that rollover handling alone cannot distinguish a true rollover from a bad reading; production code needs validation policy.

## Task 10 — Expected versus actual
Use a fixed bill example of Rs 950.00 (= 95000 paise) to compare district totals: 4,000 bills = Rs 3,800,000; 60,000 bills = Rs 57,000,000; 800,000 bills = Rs 760,000,000. These values are example calculations, not empirical measurements. Run the program and record exact observed output. Compare `float` totals against integer-paise totals on your system rather than inventing a measured discrepancy.

## Task 11 — Final recommendation
For the original monthly billing system, use explicit fixed-width or adequately wide integer types for readings and totals, integer paise for currency, centralised named tariff constants, input validation and automated boundary tests. Use `long long`/`uint64_t` for aggregate totals after calculating upper bounds. The design is only as robust as its rollover and invalid-input policy.

## Task 12 — Day-4 Smart Meter Design Challenge
**Decision: modify/redesign.** Smart meters send 35,040 interval records per house per year. Watt-hour energy readings and annual totals need wider unsigned integer types (for example `uint64_t`) after a maximum-load calculation. Tariffs should be loaded from a configuration file rather than hard-coded macros. Peak period is 18:00–22:00; the supplied starter applies a 20% surcharge when the input interval is flagged as peak. For accurate production billing, use interval timestamps and validate the tariff file, arithmetic overflow, rounding policy and time zone. The starter's input format is `watt_hours peak_flag`; it assumes peak classification is supplied by the caller.

### Complexity comparison
- Fixed slab calculation: O(1) per bill for a fixed number of slabs.
- Loop over s tariff slabs: O(s) per bill and O(s) storage for tariff tables.
- Text readings: O(d) conversion/comparison for d digits; numeric fixed-width reads are O(1) for the fixed machine type.
- Per-interval smart meter processing: O(1) per interval; yearly processing is O(n) for n intervals, with O(1) accumulator space.
- Runtime tariff loading: O(t) startup time and O(t) storage for t tariff entries; avoids recompilation for tariff updates.

## Test evidence table — fill with your actual results
| Test | Expected | Actual | Pass? |
|---|---|---|---|
| 0 units | Rs 50.00 | Fill after run | |
| 100 units | Rs 50.00 | Fill after run | |
| 150 units | Rs 162.50 | Fill after run | |
| 200 units | Rs 275.00 | Fill after run | |
| 350 units | Rs 950.00 | Fill after run | |
| Rollover 65400 -> 120 | 256 units | Fill after run | |
| Invalid input | Error handled | Fill after run | |

## Final conclusion
Integer paise prevents currency representation error; centralised tariffs improve maintainability; wider totals support district-scale aggregation; robust validation is necessary for rollover, bad readings, configuration and smart-meter intervals. Attach actual compiler output, screenshots, measurements and the final working GitHub URL before submission.
