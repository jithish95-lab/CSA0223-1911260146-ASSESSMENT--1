#include <stdio.h>
int main(void) {
    printf("7 / 2 = %d (integer division)\n", 7/2);
    printf("(double)7 / 2 = %.2f\n", (double)7/2);
    printf("0.1 + 0.2 = %.17f (binary floating-point approximation)\n", 0.1+0.2);
    printf("(int)3.99 = %d (fraction truncated)\n", (int)3.99);
    long paise=16250L;
    printf("Paise formatting: Rs %ld.%02ld\n",paise/100,paise%100);
    return 0;
}
