#include <stdio.h>
#include "billing.h"
#define FIXED_CHARGE_PAISE 5000L
#define RATE2_PAISE 225L
long compute_bill(int units) {
    long total=FIXED_CHARGE_PAISE;
    if (units>100) { int n=units-100; if(n>100)n=100; total+=(long)n*RATE2_PAISE; }
#ifdef DEBUG
    fprintf(stderr,"DEBUG: units=%d total_paise=%ld\n",units,total);
#endif
    return total;
}
int main(void) { int u=150; long p=compute_bill(u); printf("%d units -> Rs %ld.%02ld\n",u,p/100,p%100); return 0; }
