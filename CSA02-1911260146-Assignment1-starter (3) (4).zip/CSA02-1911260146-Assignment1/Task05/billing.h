#ifndef BILLING_H
#define BILLING_H
long compute_bill(int units);
#endif
