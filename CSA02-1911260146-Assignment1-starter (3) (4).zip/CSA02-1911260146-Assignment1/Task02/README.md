# Task 02

- Source: `task02.c` (Task 05 also uses `billing.h`; Task 12 uses `tariff.txt`).
- Compile with GCC 14.2.0: `gcc -std=c11 -Wall -Wextra -Wpedantic task02.c -o task02` (run from this folder).
- Capture your own terminal screenshot after running the program and save it as `output.png`.
- Record expected vs actual results and explain any difference in the report.
