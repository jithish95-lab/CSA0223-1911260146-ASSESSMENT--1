#include <stdio.h>
#include <limits.h>
#include <float.h>
typedef unsigned short meter_t;
unsigned int consumption(meter_t previous, meter_t current) {
    /* unsigned conversion makes the subtraction wrap modulo 65536 */
    return (unsigned int)(unsigned short)(current - previous);
}
int main(void) {
    printf("sizeof(meter_t) = %zu bytes, maximum reading = %u\n", sizeof(meter_t), (unsigned)USHRT_MAX);
    printf("Consumption: %u units\n", consumption(1200, 1530));
    printf("Consumption: %u units\n", consumption(65400, 120));
    printf("FLT_DIG = %d, DBL_DIG = %d, INT_MAX = %d, LLONG_MAX = %lld\n", FLT_DIG, DBL_DIG, INT_MAX, LLONG_MAX);
    return 0;
}
