#include <stdio.h>
#include <stdlib.h>
int main(void) {
    const int counts[]={4000,60000,800000};
    const long long bill_paise=95000LL; /* example bill: Rs 950.00 */
    for(size_t i=0;i<sizeof counts/sizeof counts[0];i++) {
        long long total=(long long)counts[i]*bill_paise;
        printf("%d bills: %lld paise = Rs %lld.%02lld\n",counts[i],total,total/100,total%100);
    }
    return 0;
}
