# CSA02-1911260146-Assignment1

**Student:** R. Vishwa  
**Register number:** 1911260146  
**Course:** C Programming — Assignment 1  
**Compiler used for starter validation:** GCC 14.2.0 (Linux)  

## Compile and run
For a task, open its folder and run:
```sh
gcc -std=c11 -Wall -Wextra -Wpedantic taskNN.c -o taskNN
./taskNN
```
Task05 debug build: `gcc -std=c11 -Wall -Wextra -Wpedantic -DDEBUG task05.c -o task05_debug`
Task08 compilation stages: `gcc -E task08.c -o task08.i`, `gcc -S task08.c -o task08.s`, `gcc -c task08.c -o task08.o`, `gcc task08.o -o task08`.
Task12: compile in Task12, then `./task12 tariff.txt`; enter rows as `watt_hours peak_flag`, with peak_flag 1 for 18:00–22:00 and 0 otherwise.

## Contents
Folders Task01–Task12 contain starter source code and task notes. Add input files, actual output screenshots (`output.png`), test evidence, and your analysis. Some tasks use a small demonstration program to support the written analysis; follow the supplied assignment prompt for all required discussion and evidence.

## Important academic note
Run every program yourself and verify the output on your own system. Screenshots and experimental measurements must be genuine; do not claim measurements you have not performed. Explain the implementation in your own words for the viva.

## Submission checklist
- [ ] Confirm this is the required existing repository and upload files there.
- [ ] Commit each task progressively (at least one commit per task).
- [ ] Add real output screenshots and test tables.
- [ ] Complete the report template with UML/flow diagrams, pseudocode, Big-O analysis, measurements and Task 12 defence.
- [ ] Add the working repository URL to the report cover page.
