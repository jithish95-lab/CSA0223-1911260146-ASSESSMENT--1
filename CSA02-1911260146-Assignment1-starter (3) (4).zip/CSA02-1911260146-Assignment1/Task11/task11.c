#include <stdio.h>
#define FIXED_CHARGE_PAISE 5000L
#define SLAB1_UNITS 100
#define SLAB2_UNITS 200
#define RATE2_PAISE 225L
#define RATE3_PAISE 450L
int main(void) {
    printf("Recommended: store money in integer paise; use wide integer totals.\n");
    printf("Tariff constants: fixed=%ld, slab1=%d, slab2=%d, rate2=%ld, rate3=%ld\n", FIXED_CHARGE_PAISE, SLAB1_UNITS, SLAB2_UNITS, RATE2_PAISE, RATE3_PAISE);
    return 0;
}
