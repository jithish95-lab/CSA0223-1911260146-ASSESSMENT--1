# Task 11

- Source: `task11.c` (Task 05 also uses `billing.h`; Task 12 uses `tariff.txt`).
- Compile with GCC 14.2.0: `gcc -std=c11 -Wall -Wextra -Wpedantic task11.c -o task11` (run from this folder).
- Capture your own terminal screenshot after running the program and save it as `output.png`.
- Record expected vs actual results and explain any difference in the report.
