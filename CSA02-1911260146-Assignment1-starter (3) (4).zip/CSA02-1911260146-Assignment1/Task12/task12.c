#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>
#include <string.h>
#include <stdlib.h>
typedef struct { uint64_t normal_paise_per_kwh; unsigned peak_percent; uint64_t fixed_paise; } Tariff;
static int read_tariff(const char *path,Tariff *t) {
    FILE *f=fopen(path,"r"); if(!f) return 0;
    int ok=fscanf(f,"%" SCNu64 " %u %" SCNu64,&t->normal_paise_per_kwh,&t->peak_percent,&t->fixed_paise)==3;
    fclose(f); return ok && t->peak_percent<=1000;
}
/* Each interval is a watt-hour delta. Charge is rounded to nearest paise per interval. */
static uint64_t interval_charge(uint64_t wh,uint64_t rate_paise_per_kwh,unsigned peak_percent) {
    /* wh * paise/kWh / 1000; use integer rounding, peak surcharge in percent */
    uint64_t rate=rate_paise_per_kwh;
    rate = (rate * (100u + peak_percent) + 50u) / 100u;
    return (wh * rate + 500u) / 1000u;
}
int main(int argc,char **argv) {
    if(argc!=2){fprintf(stderr,"Usage: %s tariff.txt\n",argv[0]);return 1;}
    Tariff t; if(!read_tariff(argv[1],&t)){fprintf(stderr,"Invalid tariff file. Expected: normal_rate_paise_per_kWh peak_percent fixed_charge_paise\n");return 1;}
    uint64_t total_wh=0,total_paise=t.fixed_paise,wh; unsigned interval; unsigned count=0;
    puts("Enter each interval as: watt_hours peak_flag (1=18:00-22:00, 0=off-peak). Ctrl+D to finish.");
    while(scanf("%" SCNu64 " %u",&wh,&interval)==2) {
        if(interval>1){fprintf(stderr,"peak_flag must be 0 or 1\n");return 1;}
        uint64_t charge=interval_charge(wh,t.normal_paise_per_kwh,interval?t.peak_percent:0);
        total_wh+=wh; total_paise+=charge; count++;
    }
    printf("Intervals: %u\nYear/period energy: %" PRIu64 " Wh (%.3f kWh)\n",count,total_wh,(double)total_wh/1000.0);
    printf("Bill: Rs %" PRIu64 ".%02" PRIu64 "\n",total_paise/100,total_paise%100);
    return 0;
}
