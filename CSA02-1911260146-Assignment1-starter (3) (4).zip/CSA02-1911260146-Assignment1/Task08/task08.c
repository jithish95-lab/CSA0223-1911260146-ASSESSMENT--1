#include <stdio.h>
#define DEMO_RATE 225
int main(void) { printf("Compilation pipeline demo; rate=%d paise\n", DEMO_RATE); return 0; }
