#include <stdio.h>
#define SQUARE(x) ((x) * (x))
#define MAX(a,b) ((a) > (b) ? (a) : (b))
#define RUPEES_TO_PAISE(r) ((long)(r) * 100L)
static inline int square_fn(int x) { return x*x; }
static inline int max_fn(int a,int b) { return a>b?a:b; }
int main(void) {
    int a=3,b=7;
    printf("SQUARE(a+1) = %d\n", SQUARE(a+1));
    printf("MAX(a,b) = %d\n", MAX(a,b));
    printf("RUPEES_TO_PAISE(50) = %ld\n", RUPEES_TO_PAISE(50));
    printf("inline square = %d, inline max = %d\n", square_fn(a+1), max_fn(a,b));
    return 0;
}
