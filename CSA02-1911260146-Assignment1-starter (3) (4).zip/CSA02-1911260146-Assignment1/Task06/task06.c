#include <stdio.h>
int main(void) {
    int previous, current;
    printf("Enter previous and current readings: ");
    if (scanf("%d %d", &previous, &current) != 2) { fprintf(stderr,"Invalid input: enter two integers.\n"); return 1; }
    if (previous<0 || previous>65535 || current<0 || current>65535) { fprintf(stderr,"Readings must be between 0 and 65535.\n"); return 1; }
    unsigned int units = current>=previous ? (unsigned)(current-previous) : (unsigned)(65536-previous+current);
    printf("Units consumed: %u\n", units);
    return 0;
}
